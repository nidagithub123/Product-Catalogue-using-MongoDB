const apiUrl = "http://localhost:3000/products";

// Fetch and display products
async function fetchProducts() {
  const response = await fetch(apiUrl);
  const products = await response.json();

  const tableBody = document.querySelector("#productTable tbody");
  tableBody.innerHTML = ""; // Clear table
  products.forEach((product) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${product.name}</td>
      <td>${product.category}</td>
      <td>${product.price}</td>
      <td>
        <button onclick="deleteProduct('${product._id}')">Delete</button>
        <button onclick="updateProduct('${product._id}')">Update</button>
      </td>
    `;
    tableBody.appendChild(row);
  });
}

// Add a new product
document.querySelector("#addProductForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = document.querySelector("#productName").value;
  const category = document.querySelector("#productCategory").value;
  const price = document.querySelector("#productPrice").value;

  const newProduct = {
    name: name,
    category: category,
    price: price,
  };

  await fetch(apiUrl + "/add", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(newProduct),
  });

  fetchProducts(); // Refresh the product list
});

// Delete a product
async function deleteProduct(id) {
  await fetch(`${apiUrl}/delete/${id}`, { method: "DELETE" });
  fetchProducts(); // Refresh the product list
}

// Update a product
async function updateProduct(id) {
  const name = prompt("Enter new name:");
  const category = prompt("Enter new category:");
  const price = prompt("Enter new price:");

  if (name && category && price) {
    await fetch(`${apiUrl}/update/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, category, price }),
    });
    fetchProducts(); // Refresh the product list
  }
}

// Initial fetch
fetchProducts();
