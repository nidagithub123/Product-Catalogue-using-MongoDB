const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const multer = require('multer');
const fs = require('fs');  // Required to delete image files

const app = express();
const port = 3000;

app.use(bodyParser.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));  // Ensure images are served from the uploads folder

// Multer storage configuration
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname)); // Generate unique file name
    }
});

// Multer upload settings
const upload = multer({
    storage: storage,
    limits: { fileSize: 1024 * 1024 * 5 },  // 5MB max file size
    fileFilter: (req, file, cb) => {
        const allowedFileTypes = /jpeg|jpg|png|gif/;
        const extname = allowedFileTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedFileTypes.test(file.mimetype);
        if (extname && mimetype) {
            cb(null, true);
        } else {
            cb(new Error('Only image files are allowed!'));
        }
    }
});

// MongoDB connection URI
const uri = "mongodb://127.0.0.1:27017";
const client = new MongoClient(uri);
const dbName = "ecommerce";

// MongoDB connection and routes
async function connectDB() {
    try {
        await client.connect();
        console.log("MongoDB connected!");
        const db = client.db(dbName);
        const collection = db.collection('products');

        // Add product with image
        app.post('/add', upload.single('image'), async (req, res) => {
            const { name, category, price } = req.body;
            const imagePath = req.file ? req.file.path : null; // Image path or null if no image
            const product = { name, category, price, image: imagePath };

            try {
                await collection.insertOne(product);
                res.send({ message: "Product added successfully!", product });
            } catch (err) {
                res.status(500).send({ message: "Error adding product", error: err.message });
            }
        });

        // Get all products
        app.get('/products', async (req, res) => {
            try {
                const products = await collection.find({}).toArray();
                res.send(products);
            } catch (err) {
                res.status(500).send({ message: "Error fetching products", error: err.message });
            }
        });

        // Delete product with image
        app.delete('/delete/:id', async (req, res) => {
            const { id } = req.params;
            try {
                if (!ObjectId.isValid(id)) {
                    return res.status(400).send({ message: "Invalid Product ID" });
                }

                const product = await collection.findOne({ _id: new ObjectId(id) });
                if (product && product.image && fs.existsSync(product.image)) {
                    fs.unlinkSync(product.image); // Delete image from the server
                }

                const deletedProduct = await collection.deleteOne({ _id: new ObjectId(id) });
                if (deletedProduct.deletedCount > 0) {
                    res.send({ message: "Product deleted successfully!" });
                } else {
                    res.status(404).send({ message: "Product not found." });
                }
            } catch (err) {
                res.status(500).send({ message: "Error deleting product", error: err.message });
            }
        });

        // Update product with image
        app.put('/update/:id', upload.single('image'), async (req, res) => {
            const { id } = req.params;
            const { name, category, price } = req.body;
            let updatedProduct = { name, category, price };

            // Handle image update if new image is provided
            if (req.file) {
                const oldProduct = await collection.findOne({ _id: new ObjectId(id) });
                if (oldProduct && oldProduct.image && fs.existsSync(oldProduct.image)) {
                    fs.unlinkSync(oldProduct.image); // Delete old image if new image is uploaded
                }
                updatedProduct.image = req.file.path; // Set new image path
            }

            try {
                if (!ObjectId.isValid(id)) {
                    return res.status(400).send({ message: "Invalid Product ID" });
                }

                const result = await collection.updateOne(
                    { _id: new ObjectId(id) },
                    { $set: updatedProduct }
                );

                if (result.modifiedCount > 0) {
                    res.send({ message: "Product updated successfully!" });
                } else {
                    res.status(404).send({ message: "Product not found or no changes made." });
                }
            } catch (err) {
                res.status(500).send({ message: "Error updating product", error: err.message });
            }
        });

    } catch (err) {
        console.error("Error connecting to MongoDB:", err);
        process.exit(1); // Stop the server if MongoDB connection fails
    }
}

// Connect to MongoDB and start the server
connectDB();

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
